class APIEndpoint:

    def __init__(self, api, endpoint):

        self.api = api
        self.endpoint = endpoint