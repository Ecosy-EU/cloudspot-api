class BadCredentials(ValueError):
    '''raise this when bad credentials are provided '''
