CACHE = {}
BASE_URL = 'http://localhost:8000/api/v1'
USER_AUTH_URL = 'http://localhost:8000/api/v1/authenticate-external-app'