from . import config

class AuthHandler:

    def __init__(self):
        pass